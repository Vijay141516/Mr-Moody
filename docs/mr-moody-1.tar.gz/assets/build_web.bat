@echo off
echo Installing Pygbag (WebAssembly compiler for Pygame)...
python -m pip install pygbag
echo.
echo Building the web version...
echo When the server starts, open http://localhost:8000 in your web browser!
echo Press CTRL+C in this window to stop the server when you are done.
echo.
python -m pygbag .
pause
